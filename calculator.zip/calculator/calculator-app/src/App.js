import React from 'react';
import Calculator from './components/Calculator';
import './App.css';

function App() {
  return (
    <div className="app">
      <h1>2025 Modern Calculator App</h1>
      <Calculator />
      <footer className="footer">
        <p>© {new Date().getFullYear()} 2025 Modern Calculator App</p>
        <p className="developer">Developed by Ankit Maurya</p>
      </footer>
    </div>
  );
}

export default App;
