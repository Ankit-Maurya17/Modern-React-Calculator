import React, { useState, useEffect } from 'react';
import '../styles/Calculator.css';

const Calculator = () => {
  const [input, setInput] = useState('');
  const [result, setResult] = useState('0');
  const [history, setHistory] = useState([]);
  const [showHistory, setShowHistory] = useState(false);
  
  // Handle keyboard input
  useEffect(() => {
    const handleKeyDown = (e) => {
      const key = e.key;
      
      // Handle number keys
      if (/[0-9]/.test(key)) {
        handleClick(key);
      }
      // Handle operators
      else if (['+', '-', '*', '/', '%', '='].includes(key)) {
        if (key === '*') handleClick('×');
        else if (key === '/') handleClick('÷');
        else if (key === '=' && e.shiftKey) handleClick('+');
        else handleClick(key);
      }
      // Handle decimal point
      else if (key === '.') {
        handleClick('.');
      }
      // Handle backspace
      else if (key === 'Backspace') {
        handleClick('⌫');
      }
      // Handle clear
      else if (key === 'Escape') {
        handleClick('C');
      }
      // Handle Enter key as equals
      else if (key === 'Enter') {
        handleClick('=');
      }
      // Toggle history with H key
      else if (key.toLowerCase() === 'h') {
        setShowHistory(!showHistory);
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => {
      window.removeEventListener('keydown', handleKeyDown);
    };
  }, [input, showHistory]);

  const handleClick = (value) => {
    if (value === '=') {
      if (!input) return;
      try {
        // Replace × with * and ÷ with / for evaluation
        const expression = input.replace(/×/g, '*').replace(/÷/g, '/');
        // Use Function constructor instead of eval for better security
        const evalResult = new Function('return ' + expression)().toString();
        setResult(evalResult);
        const historyItem = `${input} = ${evalResult}`;
        setHistory(prevHistory => {
          const newHistory = [historyItem, ...prevHistory].slice(0, 10); // Keep last 10 items
          return newHistory;
        });
        setInput(evalResult);
      } catch (error) {
        setResult('Error');
      }
    } else if (value === 'C') {
      setInput('');
      setResult('0');
    } else if (value === '⌫') {
      setInput(prev => prev.slice(0, -1));
    } else if (value === '±') {
      if (input) {
        if (input.startsWith('-')) {
          setInput(prev => prev.substring(1));
        } else {
          setInput(prev => '-' + prev);
        }
      }
    } else if (value === '.') {
      const nums = input.split(/[+\-×÷]/);
      if (nums[nums.length - 1].indexOf('.') === -1) {
        setInput(prev => prev + value);
      }
    } else if (value === 'H') {
      setShowHistory(!showHistory);
    } else {
      // Prevent multiple operators in a row
      const lastChar = input.slice(-1);
      if (['+', '-', '×', '÷', '%'].includes(lastChar) && ['+', '-', '×', '÷', '%'].includes(value)) {
        setInput(prev => prev.slice(0, -1) + value);
      } else {
        setInput(prev => prev + value);
      }
    }
  };

  const buttons = [
    'C', '±', '%', '÷',
    '7', '8', '9', '×',
    '4', '5', '6', '-',
    '1', '2', '3', '+',
    '0', '.', '⌫', '='
  ];

  return (
    <div className="calculator">
      <div className="display">
        <div className="history-toggle" onClick={() => setShowHistory(!showHistory)}>
          {showHistory ? 'Hide History' : 'Show History (H)'}
        </div>
        
        {showHistory ? (
          <div className="history-panel">
            <h3>Calculation History</h3>
            {history.length > 0 ? (
              <div className="history-list">
                {history.map((item, index) => (
                  <div key={index} className="history-item" onClick={() => {
                    const expression = item.split(' = ')[0];
                    setInput(expression);
                    setShowHistory(false);
                  }}>
                    {item}
                  </div>
                ))}
              </div>
            ) : (
              <p className="no-history">No history yet</p>
            )}
          </div>
        ) : (
          <>
            <div className="input">{input || '0'}</div>
            <div className="result">{result}</div>
          </>
        )}
      </div>
      
      <div className="keypad">
        {buttons.map((btn, index) => (
          <button
            key={index}
            className={`btn 
              ${btn === '=' ? 'equals' : ''} 
              ${btn === 'C' ? 'clear' : ''} 
              ${['+', '-', '×', '÷', '%', '±', '⌫'].includes(btn) ? 'operator' : ''}
              ${btn === '0' ? 'zero' : ''}
            `}
            onClick={() => handleClick(btn)}
            aria-label={btn === '×' ? 'multiply' : btn === '÷' ? 'divide' : btn}
          >
            {btn}
          </button>
        ))}
      </div>
      
      <div className="keyboard-hint">
        <p>Tip: Use your keyboard for faster input</p>
      </div>
    </div>
  );
};

export default Calculator;
